import sqlite3

def init_db():
    conn = sqlite3.connect('shop.db')
    c = conn.cursor()

    c.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                price INTEGER NOT NULL,
                image TEXT NOT NULL,
                category TEXT NOT NULL
            )
            ''')

    c.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
            ''')

    c.execute('''
            CREATE TABLE IF NOT EXISTS cart (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                quantity INTEGER DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (product_id) REFERENCES products (id)
            )
            ''')

    c.execute('DELETE FROM cart')
    c.execute('DELETE FROM products')

    c.execute('DELETE FROM sqlite_sequence WHERE name="cart"')
    c.execute('DELETE FROM sqlite_sequence WHERE name="products"')

    products = [
        ('Стиральная машина', 24999, '1.jpg', 'Крупная бытовая техника'),
        ('Холодильник', 39999, '2.jpg', 'Крупная бытовая техника'),
        ('Телевизор', 29999, '3.jpg', 'Электроника'),
        ('Микроволновая печь', 7999, '4.jpg', 'Кухонная техника'),
        ('Пылесос', 11999, '5.jpg', 'Техника для дома'),
        ('Самогонный аппарат', 42999, '6.jpg', 'Необходимая техника для дома')
    ]

    c.executemany('INSERT INTO products (title, price, image, category) VALUES (?, ?, ?, ?)', products)

    conn.commit()
    conn.close()
    print("бд успешно создана и обновлена")

if __name__ == '__main__':
    init_db()